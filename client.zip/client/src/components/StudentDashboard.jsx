import { useEffect, useState } from 'react';
import API from '../API/API.mjs';
import { Container, Spinner, Row, Col, Card, Button } from 'react-bootstrap';
import { Chart } from 'primereact/chart';
import { useNavigate } from 'react-router-dom';

function StudentDashboard() {
    const [summary, setSummary] = useState({
        name: '',
        open: 0,
        closed: 0,
        avg: null,
        total: 0,
        submitted: 0
    });
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const loadData = async () => {
            try {
                const user = await API.getUserInfo();
                const assignments = await API.getStudentAssignmentsWithDetails();

                const open = assignments.filter(a => a.isOpen).length;
                const closed = assignments.filter(a => !a.isOpen).length;
                const total = assignments.length;
                const answered = assignments.filter(a => a.answerText).length;

                const evaluated = assignments.filter(a => !a.isOpen && a.evaluation !== null);
                const { scoreSum, weight } = evaluated.reduce((acc, a) => {
                    const groupSize = a.group?.length || 1;
                    const w = 1 / groupSize;
                    acc.scoreSum += a.evaluation * w;
                    acc.weight += w;
                    return acc;
                }, { scoreSum: 0, weight: 0 });

                const avg = weight > 0 ? scoreSum / weight : null;

                const submitted = (answered / (total || 1)) * 100;

                setSummary({
                    name: user.name,
                    open,
                    closed,
                    avg,
                    total,
                    submitted
                });
            } catch (error) {
                console.error('Error loading data student dashboard :', error);
            } finally {
                setLoading(false);
            }
        };

        loadData();
    }, []);

    if (loading) return <Spinner animation="border" className="m-5" />;

    const chartData = {
        labels: ['Open', 'Closed'],
        datasets: [{
            data: [summary.open || 0, summary.closed || 0],
            backgroundColor: ['#42A5F5', '#66BB6A'],
            hoverBackgroundColor: ['#64B5F6', '#81C784']
        }]
    };

    return (
        <Container className="mt-4">
            <Row className="mb-4">
                <Col>
                    <Button variant="primary" className="me-2" disabled>Home</Button>
                    <Button variant="outline-primary" onClick={() => navigate('/student/assignments')}>Assignments</Button>
                </Col>
            </Row>

            {/* Student profile */}
            <Card className="p-4">
                <Row>
                    <Col md={8}>
                        <h5>Your Profile</h5>
                        <p>Hi {summary.name}! You have submitted {summary.submitted.toFixed(0)}% of your assignments</p>

                        <h6 className="mt-4">Average</h6>
                        {summary.avg !== null ? (
                            <div className="progress" style={{ height: '24px' }}>
                                <div
                                    className="progress-bar bg-success"
                                    role="progressbar"
                                    style={{ width: `${(summary.avg / 30) * 100}%` }}
                                >
                                    {summary.avg.toFixed(1)}/30
                                </div>
                            </div>
                        ) : (
                            <p className="text-muted">No evaluation </p>
                        )}
                    </Col>

                    <Col md={4} className="d-flex align-items-center justify-content-center">
                        <div style={{ maxWidth: '200px' }}>
                            <Chart type="pie" data={chartData} />
                        </div>
                    </Col>
                </Row>
            </Card>
        </Container>
    );
}

export default StudentDashboard;
