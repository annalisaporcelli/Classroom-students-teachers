// Lista assignment aperti (modificabili)
export function OpenAssignmentsList({ assignments, onEdit }) {
    return (
        <div>
            <h5>Open assignments</h5>
            {assignments.length === 0 ? <p>No open assignment.</p> :
                assignments.map(a => (
                    <div key={a.id} className="mb-2">
                        <strong>{a.question}</strong>
                        <button className="btn btn-outline-primary btn-sm ms-2" onClick={() => onEdit(a)}>
                            Modify answer
                        </button>
                    </div>
                ))
            }
        </div>
    );
}


