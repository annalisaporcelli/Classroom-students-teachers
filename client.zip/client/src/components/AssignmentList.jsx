import React, { useState } from 'react';
import { Table, Form, Collapse, Button } from 'react-bootstrap';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import API from "../API/API.mjs";
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'primeicons/primeicons.css';

function AssignmentList({ assignments, reloadAssignments }) {
    const [evaluations, setEvaluation] = useState({});
    const [expanded, setExpanded] = useState(null);

    const handleChange = (id, value) => {
        setEvaluation(prev => ({ ...prev, [id]: value }));
    };

    const handleSubmit = async (id) => {
        const evaluation = parseInt(evaluations[id]);
        if (isNaN(evaluation) || evaluation < 0 || evaluation > 30) {
            return alert('Invalid mark. Must be between 0 and 30.');
        }

        try {
            await API.evaluateAssignment(id, evaluation);
            await reloadAssignments();
        } catch (err) {
            console.error('Error during evaluation:', err);
        }
    };

    const confirmAddMark = (assignmentId, evaluation) => {
        confirmDialog({
            message: `Confirm score submission ${evaluation}?`,
            header: 'Confirm score',
            icon: 'pi pi-question-circle',
            accept: async () => {
                await handleSubmit(assignmentId);
            }
        });
    };

    return (
        <>
            <ConfirmDialog />

            <Table bordered>
                <thead className="table-primary text-center">
                    <tr>
                        <th style={{ whiteSpace: 'nowrap' }}>ASSIGNMENTS LIST</th>
                        <th style={{ whiteSpace: 'nowrap' }}>STATUS</th>
                        <th style={{ whiteSpace: 'nowrap' }}>SCORE</th>
                        <th style={{ whiteSpace: 'nowrap' }}>DETAILS</th>
                    </tr>
                </thead>
                <tbody>
                    {assignments.map(a => {
                        const isExpanded = expanded === a.id;

                        return (
                            <React.Fragment key={a.id}>
                                <tr>
                                    <td>
                                        <div
                                            style={{
                                                maxHeight: '80px',
                                                overflowY: 'auto',
                                                backgroundColor: '#f8f9fa',
                                                padding: '5px',
                                                borderRadius: '4px',
                                                border: '1px solid rgb(0, 78, 180)'
                                            }}
                                        >
                                            <strong>Question: </strong>{a.question}
                                        </div>
                                    </td>
                                    <td className="text-center">
                                        {a.isOpen ? (
                                            <span className="text-success fw-bold">
                                                <i className="pi pi-lock-open me-2"></i>
                                            </span>
                                        ) : (
                                            <span className="text-danger fw-bold">
                                                <i className="pi pi-lock me-2"></i>
                                            </span>
                                        )}
                                    </td>
                                    <td>
                                        {a.isOpen && a.answer ? (
                                            <div className="d-flex align-items-center gap-2">
                                                <Form.Control
                                                    type="number"
                                                    placeholder="Score"
                                                    value={evaluations[a.id] ?? ''}
                                                    onChange={e => handleChange(a.id, e.target.value)}
                                                    style={{ width: '80px' }}
                                                />
                                                <Button
                                                    variant="primary"
                                                    size="sm"
                                                    onClick={() => confirmAddMark(a.id, evaluations[a.id])}
                                                ><i className="bi bi-cursor-fill"></i></Button>
                                            </div>
                                        ) : (
                                            <div className="text-center">{a.evaluation ?? '-'}</div>
                                        )}
                                    </td>
                                    <td>
                                        <Button
                                            variant="outline-primary"
                                            size="sm"
                                            onClick={() => setExpanded(prev => (prev === a.id ? null : a.id))}
                                        >
                                            {isExpanded ? 'Hide' : <i className="pi pi-search"></i>}
                                        </Button>
                                    </td>
                                </tr>
                                <tr>
                                    <td colSpan={4} style={{ padding: 0, borderTop: 'none' }}>
                                        <Collapse in={isExpanded}>
                                            <div className="p-3 bg-light border-top">
                                                <p><strong>Answer:</strong> {a.answer}</p>
                                                <p><strong>Group members:</strong> {a.group.map(s => s.name).join(', ')}</p>
                                            </div>
                                        </Collapse>
                                    </td>
                                </tr>
                            </React.Fragment>
                        );
                    })}
                </tbody>
            </Table>
        </>
    );
}

export default AssignmentList;
