import { useState } from 'react';
import { Form, Button, Alert } from 'react-bootstrap';
import { Link } from 'react-router-dom';

function LoginForm({ handleLogin }) {
    const [credentials, setCredentials] = useState({ username: '', password: '' });
    const [message, setMessage] = useState('');
    const [isPending, setIsPending] = useState(false);

    const handleChange = (event) => {
        const { name, value } = event.target;
        setCredentials((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setMessage('');
        setIsPending(true);

        try {
            await handleLogin(credentials);
        } catch (err) {
            const errorMessage = err?.message === "Unauthorized"
                ? "Email or password incorrect."
                : "Login failed. Please try again.";
            setMessage(errorMessage);
        } finally {
            setIsPending(false);
        }
    };

    return (
        <div className="d-flex justify-content-center mt-5">
            <div className="p-4 border rounded shadow" style={{ minWidth: '350px', maxWidth: '500px', width: '100%' }}>
                {message && <Alert variant="danger">{message}</Alert>}
                {isPending && <Alert variant="warning">Please wait for the server's response...</Alert>}

                <Form onSubmit={handleSubmit}>
                    <Form.Group controlId='username' className='mb-3'>
                        <Form.Label>Email</Form.Label>
                        <Form.Control
                            type='email'
                            name='username'
                            required
                            value={credentials.username}
                            onChange={handleChange}
                        />
                    </Form.Group>

                    <Form.Group controlId='password' className='mb-3'>
                        <Form.Label>Password</Form.Label>
                        <Form.Control
                            type='password'
                            name='password'
                            required
                            minLength={6}
                            value={credentials.password}
                            onChange={handleChange}
                        />
                    </Form.Group>

                    <div className="d-flex justify-content-between">
                        <Button type='submit' disabled={isPending}>
                            Login
                        </Button>

                        <Link className='btn btn-danger' to='/'>
                            Cancel
                        </Link>
                    </div>
                </Form>
            </div>
        </div>
    );
}

function LogoutButton({ logout }) {
    return (
        <Button variant='outline-light' onClick={logout}>
            <i className="pi pi-sign-out me-2"></i> Logout
        </Button>
    );
}

export { LoginForm, LogoutButton };
