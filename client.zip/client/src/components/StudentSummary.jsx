import { Chart } from 'primereact/chart';
import { ProgressBar } from 'primereact/progressbar';

export function StudentSummary({ summary, chartData }) {
    const avg = summary.avg;

    return (
        <div className="mb-4">
            <h4>Hi {summary.name}</h4>

            <h6>Assignment Distribution</h6>
            <div style={{ maxWidth: '300px', margin: '0 auto' }}>
                <Chart type="pie" data={chartData} className="mb-3" />
            </div>

            <h6>Average scores</h6>
            <ProgressBar
                value={(avg / 30) * 100}
                displayValueTemplate={() => `${avg?.toFixed(1) ?? 'N/A'}/30`}
            />
        </div>
    );
}
