import { useEffect, useState } from 'react';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import API from '../API/API.mjs';
import {
    Container, Row, Col, Dropdown, ButtonGroup, Button,
    Collapse, Spinner
} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

function StudentAssignmentsPage() {
    const [assignments, setAssignments] = useState([]);
    const [teacherFilter, setTeacherFilter] = useState('ALL');
    const [teachers, setTeachers] = useState([]);
    const [statusFilter, setStatusFilter] = useState('OPEN');
    const [loading, setLoading] = useState(true);
    const [selectedAssignment, setSelectedAssignment] = useState(null);
    const [showClosedDetails, setShowClosedDetails] = useState(null);

    const navigate = useNavigate();

    useEffect(() => {
        const load = async () => {
            try {
                const [assignments, teacherList] = await Promise.all([
                    API.getStudentAssignmentsWithDetails(),
                    API.getAllTeachers()
                ]);
                setAssignments(assignments);
                setTeachers(teacherList.map(t => t.name));
            } catch (err) {
                console.error('Loading error:', err);
            } finally {
                setLoading(false);
            }
        };
        load();
    }, []);

    const handleSave = async () => {
        await API.submitAnswer(selectedAssignment.id, selectedAssignment.answerText);
        setSelectedAssignment(null);
        const refreshed = await API.getStudentAssignmentsWithDetails();
        setAssignments(refreshed);
    };

    const filteredAssignments = assignments
        .filter(a => teacherFilter === 'ALL' || a.teacherName === teacherFilter)
        .filter(a => {
            if (statusFilter === 'OPEN') return a.isOpen;
            if (statusFilter === 'CLOSED') return !a.isOpen;
            return true;
        });

    return (
        <>
            <ConfirmDialog />

            <Container className="mt-4">
                {/* Home | Assignments Buttons */}
                <Row className="mb-4">
                    <Col>
                        <Button variant="outline-primary" onClick={() => navigate('/student')}> Home</Button>
                        <Button variant="primary" className="ms-2" disabled>Assignments</Button>
                    </Col>
                </Row>

                {/* ALL TEACHER | TEACHER # DROPDOWN */}
                <h4 className="mb-3">Assignments list </h4>

                <Row className="mb-3 align-items-center">
                    <Col xs="auto">
                        <Dropdown onSelect={setTeacherFilter}>
                            <Dropdown.Toggle variant="primary">
                                <span className="pi pi-users me-2"></span>
                                {teacherFilter === 'ALL' ? 'ALL TEACHERS' : teacherFilter}
                            </Dropdown.Toggle>
                            <Dropdown.Menu>
                                <Dropdown.Item eventKey="ALL">ALL TEACHERS</Dropdown.Item>
                                {teachers.map(t => (
                                    <Dropdown.Item key={t} eventKey={t}>{t}</Dropdown.Item>
                                ))}
                            </Dropdown.Menu>
                        </Dropdown>
                    </Col>
                    <Col xs="auto">

                        {/* OPEN | CLOSED BUTTON */}
                        <ButtonGroup>
                            <Button
                                variant={statusFilter === 'OPEN' ? 'success' : 'outline-success'}
                                onClick={() => setStatusFilter('OPEN')}
                            >
                                <i className="pi pi-lock-open me-1"></i> Open
                            </Button>
                            <Button
                                variant={statusFilter === 'CLOSED' ? 'danger' : 'outline-danger'}
                                onClick={() => setStatusFilter('CLOSED')}
                            >
                                <i className="pi pi-lock me-1"></i> Closed
                            </Button>
                        </ButtonGroup>

                    </Col>
                </Row>

                {/* Assignments list */}
                {loading ? <Spinner animation="border" /> : (
                    <>
                        {filteredAssignments.length === 0 && (
                            <p className="text-muted">No assignment found.</p>
                        )}

                        {filteredAssignments.map(a => (
                            <div key={a.id} className="mb-3 p-3 border rounded">
                                <div className="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{a.question}</strong>{' '}
                                        <span className="text-muted">({a.teacherName})</span>
                                    </div>
                                    {statusFilter === 'OPEN' && (
                                        <Button
                                            variant="primary"
                                            onClick={() =>
                                                setSelectedAssignment({ ...a, answerText: a.answerText ?? '' })
                                            }
                                        >
                                            <span className="pi pi-pencil me-1"></span> Answer
                                        </Button>
                                    )}
                                    {statusFilter === 'CLOSED' && (
                                        <Button
                                            variant="outline-secondary"
                                            onClick={() =>
                                                setShowClosedDetails(showClosedDetails === a.id ? null : a.id)
                                            }
                                        >
                                            {showClosedDetails === a.id ? 'Hide' : 'Details'}
                                        </Button>
                                    )}
                                </div>

                                {selectedAssignment?.id === a.id && (
                                    <div className="mt-3">
                                        <textarea
                                            className="form-control mb-2"
                                            rows={4}
                                            value={selectedAssignment.answerText}
                                            onChange={(e) =>
                                                setSelectedAssignment(prev => ({
                                                    ...prev,
                                                    answerText: e.target.value
                                                }))
                                            }
                                        />
                                        <Button
                                            className="me-2"
                                            variant="success"
                                            onClick={() => {
                                                confirmDialog({
                                                    message: 'Are you sure you want to submit the answer?',
                                                    header: 'Confirm Submission',
                                                    icon: 'pi pi-exclamation-triangle',
                                                    acceptLabel: 'Yes',
                                                    rejectLabel: 'No',
                                                    accept: () => handleSave(),
                                                    reject: () => { }
                                                });
                                            }}
                                        >
                                            Save
                                        </Button>
                                        <Button variant="secondary" onClick={() => setSelectedAssignment(null)}>
                                            Cancel
                                        </Button>
                                    </div>
                                )}

                                {showClosedDetails === a.id && (
                                    <Collapse in={showClosedDetails === a.id}>
                                        <div className="mt-3">
                                            <p><strong>Answer:</strong> {a.answerText}</p>
                                            <p><strong>Score:</strong> {a.evaluation}</p>
                                            <p><strong>Group:</strong> {a.group?.map(s => s.name).join(', ')}</p>
                                        </div>
                                    </Collapse>
                                )}
                            </div>
                        ))}
                    </>
                )}
            </Container>
        </>
    );
}

export default StudentAssignmentsPage;
