import { Container, Navbar } from 'react-bootstrap';
import { Link } from "react-router";
import { LogoutButton } from './AuthComponents';
import 'primeicons/primeicons.css';

function NavHeader(props) {
  return (
    <Navbar bg='primary' data-bs-theme='dark'>
      <Container fluid>
        <Link to="/" className="navbar-brand"><i className="bi bi-house-door"></i> Home</Link>

        {props.loggedIn ? (
          <LogoutButton logout={props.handleLogout} />
        ) : (
          <Link to='/login' className='btn btn-outline-light'>
            <i className="pi pi-sign-in me-2"></i> Login
          </Link>
        )}
      </Container>
    </Navbar>
  );
}

export default NavHeader;
