import { useState, useEffect } from 'react';
import { Form, Alert } from 'react-bootstrap';
import { MultiSelect } from 'primereact/multiselect';
import { Button } from 'primereact/button';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import API from "../API/API.mjs";

function CreateAssignment({ students, onCreate }) {
    const [question, setQuestion] = useState('');
    const [selectedIds, setSelectedIds] = useState([]);
    const [errorMsg, setErrorMsg] = useState('');
    const [successMsg, setSuccessMsg] = useState('');

    useEffect(() => {
        setQuestion('');
        setSelectedIds([]);
        setErrorMsg('');
        setSuccessMsg('');
    }, []);

    const submitAssignment = async () => {
        const onlyIds = selectedIds.map(s => s.id);
        try {
            await API.createAssignment(question, onlyIds);
            setQuestion('');
            setSelectedIds([]);
            setSuccessMsg('Assignment created successfully!');
            const updated = await API.getTeacherAssignments();
            onCreate(updated);
        } catch (err) {
            setErrorMsg('Error during assignment creation. ' + err.message);
        }
    };

    const handleConfirm = () => {
        setErrorMsg('');
        setSuccessMsg('');

        const onlyIds = selectedIds.map(s => s.id);
        if (onlyIds.length < 2 || onlyIds.length > 6) {
            setErrorMsg('Select among 2 and 6 students.');
            return;
        }
        if (!question.trim()) {
            setErrorMsg('Question cannot be empty.');
            return;
        }

        confirmDialog({
            message: 'Do you want to submit this assignment?',
            header: 'Confirm submission',
            icon: 'pi pi-exclamation-triangle',
            accept: submitAssignment
        });
    };

    return (
        <div>
            <ConfirmDialog />

            <Form.Group className="mb-3">
                <Form.Label>Question</Form.Label>
                <Form.Control
                    type="text"
                    placeholder="Insert text of question"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                />
            </Form.Group>

            <Form.Group className="mb-3">
                <Form.Label>Select students (tra 2 e 6)</Form.Label>
                <MultiSelect
                    value={selectedIds}
                    onChange={(e) => setSelectedIds(e.value)}
                    options={students}
                    optionLabel="name"
                    placeholder="Select students"
                    display="chip"
                    className="w-100"
                    filter
                />
            </Form.Group>

            {errorMsg && <Alert variant="danger">{errorMsg}</Alert>}
            {successMsg && <Alert variant="success">{successMsg}</Alert>}

            <Button type="button" icon="pi pi-check" label="SUBMIT" onClick={handleConfirm} />
        </div>
    );
}

export default CreateAssignment;
