import { useEffect, useState } from 'react';
import API from '../API/API.mjs';
import { useNavigate } from 'react-router';
import { Container, Card, Row, Col, Spinner } from 'react-bootstrap';
import { PersonFill } from 'react-bootstrap-icons';

function TeacherHome() {
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        const loadStudents = async () => {
            try {
                const data = await API.getAllStudents();
                setStudents(data);
            } catch (err) {
                console.error('Error loadin students:', err);
            } finally {
                setLoading(false);
            }
        };
        loadStudents();
    }, []);

    if (loading) return <Spinner animation="border" className="m-5" />;

    return (
        <Container className="mt-4">
            <h3 className="mb-4">My Classes</h3>
            <Row>
                <Col md={4}>
                    <Card
                        bg="danger"
                        text="white"
                        className="mb-3 shadow"
                        style={{ cursor: 'pointer' }}
                        onClick={() => navigate('/teacher/class')}
                    >
                        <Card.Body className="d-flex flex-column align-items-center">
                            <Card.Title>Class 1</Card.Title>
                            <div className="d-flex align-items-center gap-2 mt-2">
                                <PersonFill size={24} />
                                <span>{students.length}</span>
                            </div>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </Container>
    );
}

export default TeacherHome;
