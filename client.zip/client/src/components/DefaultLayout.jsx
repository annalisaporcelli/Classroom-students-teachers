import { useEffect, useState } from "react";
import { Alert, Container, Row } from "react-bootstrap";
import { Outlet } from "react-router";
import NavHeader from "./NavHeader";
import API from "../API/API.mjs";

function DefaultLayout({ loggedIn, handleLogout, message, setMessage, user }) {
  const [assignments, setAssignments] = useState([]);

  const [loadingAssignments, setLoadingAssignments] = useState(true); // Tracks whether assignments still loading


  useEffect(() => {
    if (loggedIn && user?.role === 'student') {
      const loadAssignments = async () => {
        try {
          const data = await API.getStudentAssignmentsWithDetails();
          setAssignments(data);
        } catch (err) {
          console.error("Error loading assignments:", err);
        } finally {
          setLoadingAssignments(false);
        }
      };
      loadAssignments();
    }
  }, [loggedIn, user]);

  return (
    <>
      <NavHeader loggedIn={loggedIn} handleLogout={handleLogout} user={user} />

      <Container fluid className="mt-4">
        {message && (
          <Row>
            <Alert
              variant={message.type}
              onClose={() => setMessage('')}
              dismissible
            >
              {typeof message.msg === 'string' ? message.msg : JSON.stringify(message.msg)}
            </Alert>
          </Row>
        )}

        <Outlet context={{ assignments, setAssignments, loadingAssignments }} />
      </Container>
    </>
  );
}

export default DefaultLayout;
