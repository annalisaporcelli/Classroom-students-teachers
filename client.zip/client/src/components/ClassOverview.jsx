import { useEffect, useState } from 'react';
import { Table, Spinner, Alert } from 'react-bootstrap';
import API from '../API/API.mjs';

export default function ClassOverview() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [sortKey, setSortKey] = useState('name');
    const [ascending, setAscending] = useState(true);

    useEffect(() => {
        API.getClassSummary()
            .then(rows => setData(rows))
            .catch(err => setError(err.message))
            .finally(() => setLoading(false));
    }, []);

    const toggleSort = (key) => {
        if (sortKey === key) {
            setAscending(!ascending);
        } else {
            setSortKey(key);
            setAscending(true);
        }
    };

    const sortedData = [...data].sort((a, b) => {
        let result = 0;
        if (sortKey === 'name') result = a.name.localeCompare(b.name);
        if (sortKey === 'total') result = (a.openCount + a.closedCount) - (b.openCount + b.closedCount);
        if (sortKey === 'avg') result = (a.weightedAvg ?? 0) - (b.weightedAvg ?? 0);
        return ascending ? result : -result;
    });

    if (loading) return <Spinner animation="border" />;
    if (error) return <Alert variant="danger">{error}</Alert>;

    return (
        <Table striped bordered hover>
            <thead>
                <tr>
                    <th>
                        Student{' '}
                        <i
                            className="pi pi-sort-alt"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleSort('name')}
                        />
                    </th>
                    <th>Open</th>
                    <th>Closed</th>
                    <th>
                        Weighted Avg{' '}
                        <i
                            className="pi pi-sort-alt"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleSort('avg')}
                        />
                    </th>
                    <th>
                        # Assignments{' '}
                        <i
                            className="pi pi-sort-alt"
                            style={{ cursor: 'pointer' }}
                            onClick={() => toggleSort('total')}
                        />
                    </th>
                </tr>
            </thead>
            <tbody>
                {sortedData.map(s => (
                    <tr key={s.id}>
                        <td>{s.name}</td>
                        <td>{s.openCount}</td>
                        <td>{s.closedCount}</td>
                        <td>{s.weightedAvg?.toFixed(2) || '-'}</td>
                        <td>{s.openCount + s.closedCount}</td>
                    </tr>
                ))}
            </tbody>
        </Table>
    );
}
