import { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router";
import { useNavigate } from "react-router";

import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import "bootstrap/dist/css/bootstrap.min.css";

import { LoginForm } from "./components/AuthComponents";
import API from "./API/API.mjs";

import DefaultLayout from "./components/DefaultLayout";
import NotFound from "./components/NotFound";
import TeacherDashboard from './components/TeacherDashboard';
import TeacherHome from "./components/TeacherHome";
import StudentDashboard from './components/StudentDashboard';
import StudentAssignmentsPage from './components/StudentAssignmentsPage';


function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [loadingUser, setLoadingUser] = useState(true);

  const [message, setMessage] = useState('');
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const user = await API.getUserInfo();
        setLoggedIn(true);
        setUser(user);
      } catch (err) {
        setLoggedIn(false);
        setUser(null);
      } finally {
        setLoadingUser(false);
      }
    };
    checkAuth();

  }, []);

  useEffect(() => {
    if (loggedIn && user) {
      if (user.role === 'teacher') navigate('/teacher');
      else if (user.role === 'student') navigate('/student');
    }
  }, [loggedIn, user]);


  const handleLogin = async (credentials) => {
    try {
      const user = await API.logIn(credentials);
      setLoggedIn(true);
      setUser(user);
      setMessage({ msg: `Welcome, ${user.name}!`, type: 'success' });
    } catch (err) {
      const errorMessage = err?.message === "Unauthorized"
        ? "Email or password incorrect."
        : "Login failed. Please try again.";
      setMessage({ msg: errorMessage, type: 'danger' });
    }
  };



  const handleLogout = async () => {
    await API.logOut();
    setLoggedIn(false);
    setUser(null);
    setMessage('');
  };

  if (loadingUser) return null; // Block rendering until user info is loaded

  return (
    <Routes>
      <Route element={<DefaultLayout
        loggedIn={loggedIn}
        handleLogout={handleLogout}
        message={message}
        setMessage={setMessage}
        user={user}
      />
      }
      >

        <Route path="/" element={loggedIn && user ? <Navigate to={user.role === 'teacher' ? "/teacher" : "/student"} replace />
          : (<div className="text-center mt-5">
            <h2 > <strong>Class Assignments</strong></h2>
            <h4 > Web Applications I 2024/25 </h4>
            <h4 > Exam #2 </h4>
          </div>
          )}
        />
        <Route path="/login" element={<LoginForm handleLogin={handleLogin} />} />

        <Route path="/teacher" element={loggedIn && user?.role === 'teacher' ? (<TeacherHome />) : (<Navigate to="/" />)} />

        <Route path="/teacher/class" element={loggedIn && user?.role === 'teacher' ? (<TeacherDashboard />) : (<Navigate to="/" />)} />

        <Route path="/student" element={loggedIn && user?.role === 'student' ? (<StudentDashboard user={user} />) : (<Navigate to="/" />)} />

        <Route path="/student/assignments" element={loggedIn && user?.role === 'student' ? (<StudentAssignmentsPage />) : (<Navigate to="/" />)} />

        <Route
          path="*" element={<NotFound />} />
      </Route>

    </Routes>
  );
}

export default App;
