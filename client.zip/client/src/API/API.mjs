const Url = 'http://localhost:3001/api';

// SESSION API
async function logIn(credentials) {
  const response = await fetch(Url + '/sessions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify(credentials)
  });

  if (response.ok) {
    return await response.json();
  } else {
    const errMessage = await response.text();
    throw new Error(errMessage || "failed login");
  }
}

async function logOut() {
  const response = await fetch(Url + '/sessions/current', {
    method: 'DELETE',
    credentials: 'include',
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error || "Logout failed");
  }
}

// GET INFO USER 
async function getUserInfo() {
  const response = await fetch(Url + '/sessions/current', {
    credentials: 'include'
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || "Unauthenticated");
  }

  return data;
}
// GET STUDENTS & TEACHERS
async function getAllStudents() {
  const response = await fetch(Url + '/students', {
    credentials: 'include'
  });

  if (!response.ok)
    throw new Error("Failed to load students");

  return await response.json();
}

async function getAllTeachers() {
  const response = await fetch(Url + '/teachers', {
    credentials: 'include'
  });

  if (!response.ok)
    throw new Error("Failed to load teachers");

  return await response.json();
}

// ASSIGNMENTS: TEACHER
async function getTeacherAssignments() {
  const response = await fetch(Url + '/teacher/assignments', {
    credentials: 'include'
  });

  if (!response.ok)
    throw new Error("Failed to retrieve assignments");

  return await response.json();
}

async function createAssignment(question, studentIds) {
  const response = await fetch(Url + '/teacher/assignments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ question, studentIds })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || "Error creating assignment");
  }

  return null;
}

async function evaluateAssignment(id, evaluation) {
  const response = await fetch(`${Url}/assignments/${id}/evaluate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ evaluation })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || "Evaluation failed");
  }

  return null;
}

async function getTeacherAssignmentsWithDetails() {
  const response = await fetch(Url + '/teacher/assignments/details', {
    credentials: 'include'
  });

  if (!response.ok)
    throw new Error("Failed to load assignment details");

  return await response.json();
}

// CLASS SUMMARY
async function getClassSummary() {
  const response = await fetch(Url + '/teacher/class', {
    credentials: 'include'
  });

  if (!response.ok)
    throw new Error("Failed to load class summary");

  return await response.json();
}

// ASSIGNMENTS: STUDENT
async function getStudentAssignments() {
  const response = await fetch(Url + '/student/assignments', {
    credentials: 'include'
  });

  if (!response.ok)
    throw new Error("Failed to retrieve assignments");

  return await response.json();
}

async function getStudentAssignmentsWithDetails() {
  const response = await fetch(Url + '/student/assignments/details', {
    credentials: 'include'
  });

  if (!response.ok)
    throw new Error("Failed to retrieve detailed assignments");

  return await response.json();
}

async function submitAnswer(assignmentId, text) {
  const response = await fetch(`${Url}/assignments/${assignmentId}/answer`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: JSON.stringify({ text })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || "Failed to submit answer");
  }

  return null;
}

// SHARED
async function getAssignmentAnswers(assignmentId) {
  const response = await fetch(`${Url}/assignments/${assignmentId}/answers`, {
    credentials: 'include'
  });

  if (!response.ok)
    throw new Error("Failed to load assignment answers");

  return await response.json();
}

// EXPORT API OBJECT
const API = {
  logIn,
  logOut,
  getUserInfo,
  getAllStudents,
  getAllTeachers,
  getTeacherAssignments,
  getTeacherAssignmentsWithDetails,
  createAssignment,
  evaluateAssignment,
  getClassSummary,
  getStudentAssignments,
  getStudentAssignmentsWithDetails,
  submitAnswer,
  getAssignmentAnswers
};

export default API;
