//Data Access Object (DAO) module for accessing 

import sqlite from 'sqlite3';
import { Assignment, User, Answer } from './QAModels.mjs';
import crypto from 'crypto';
import dayjs from 'dayjs';

const db = new sqlite.Database('db.sqlite', (err) => {
  if (err) throw err;
});

// Retrieves all assignments for a student with their details
export function getStudentAssignmentsWithDetails(studentId) {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT a.*, ans.text AS answerText, t.name AS teacherName 
      FROM assignments a 
      JOIN groups g ON g.assignment_id = a.id
      LEFT JOIN answers ans ON ans.assignment_id = a.id
      LEFT JOIN user t ON a.teacher_id = t.id
      WHERE g.student_id = ?
    `;

    db.all(sql, [studentId], async (err, rows) => {
      if (err) return reject(err);

      try {
        const result = await Promise.all(rows.map(async a => { // For each assignment
          const group = await getAssignmentGroup(a.id); // Get the group of students 
          return { ...a, group }; // Return the assignment with its group
        }));
        resolve(result); // Resolve promise
      } catch (err2) {
        reject(err2);
      }
    });
  });
}


//Teacher
export function getTeacherAssignments(teacherId) { // All assignments for a teacher with their latest answer
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT a.*,
        (SELECT text FROM answers ans WHERE ans.assignment_id = a.id ORDER BY submission_date DESC LIMIT 1) AS answer
      FROM assignments a
      WHERE a.teacher_id = ?
    `;

    db.all(sql, [teacherId], async (err, rows) => {
      if (err) return reject(err);

      try {
        const result = await Promise.all(rows.map(async (a) => {
          try {
            const group = await getAssignmentGroup(a.id);
            return { ...a, group };
          } catch (innerErr) {
            console.error(`Error getAssignmentGroup ${a.id}:`, innerErr);
            return { ...a, group: [] };
          }
        }));
        resolve(result);
      } catch (outerErr) {
        console.error('Error in Promise.all di getTeacherAssignments:', outerErr);
        reject(outerErr);
      }
    });
  });
}


// Group of students for a given assignment
export function getAssignmentGroup(assignmentId) {
  return new Promise((resolve, reject) => {
    const sql = `SELECT user.id, user.name, user.email, user.role
                 FROM groups JOIN user ON user.id = groups.student_id 
                 WHERE groups.assignment_id = ?`;
    db.all(sql, [assignmentId], (err, rows) => {
      if (err) {
        reject(err);
      } else {
        const group = rows.map(a => new User(a.id, a.name, a.email, a.role));
        resolve(group);
      }
    });
  });
}

// Creates a new assignment with the given question, teacher Id, and students Id
export function createAssignment(question, teacherId, studentIds) {
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO assignments(question, isOpen, teacher_id) VALUES (?, 1, ?)`;
    db.run(sql, [question, teacherId], function (err) {
      if (err) return reject(err);
      const assignmentId = this.lastID;
      const groupSql = `INSERT INTO groups(assignment_id, student_id) VALUES (?, ?)`;

      const stmt = db.prepare(groupSql);
      for (const studentId of studentIds) {
        stmt.run(assignmentId, studentId);
      }
      stmt.finalize((e) => {
        if (e) return reject(e);
        resolve(assignmentId);
      });
    });
  });
}

// All assignments for a student
export function getStudentAssignments(studentId) {
  return new Promise((resolve, reject) => {
    const sql = `SELECT a.*
                 FROM assignments AS a
                 JOIN groups AS g ON a.id = g.assignment_id
                 WHERE g.student_id = ?`;
    db.all(sql, [studentId], (err, rows) => {
      if (err) return reject(err);
      const result = rows.map(a => new Assignment(a.id, a.question, a.isOpen, a.evaluation, a.teacher_id, a.created_at));
      resolve(result);
    });
  });
}


// Adds or updates an answer for a given assignment
export function addOrUpdateAnswer({ assignmentId, text }) {
  return new Promise((resolve, reject) => { // 
    const sqlCheck = `SELECT id FROM answers WHERE assignment_id = ?`;
    db.get(sqlCheck, [assignmentId], (err, row) => {
      if (err) return reject(err);
      const now = dayjs().format("YYYY-MM-DD");

      if (row) {
        const sql = `UPDATE answers SET text = ?, submission_date = ? WHERE id = ?`;
        db.run(sql, [text, now, row.id], function (e) {
          if (e) return reject(e);
          resolve(row.id);
        });
      } else {
        const sql = `INSERT INTO answers(assignment_id, text, submission_date)
                     VALUES (?, ?, ?)`;
        db.run(sql, [assignmentId, text, now], function (e) {
          if (e) return reject(e);
          resolve(this.lastID);
        });
      }
    });
  });
}



// Retrieves all assignments for a teacher with their answers
export function evaluateAssignment(assignmentId, evaluation) {
  return new Promise((resolve, reject) => {
    const sql = `UPDATE assignments SET evaluation = ?, isOpen = 0 WHERE id = ?`;
    db.run(sql, [evaluation, assignmentId], function (err) {
      if (err) return reject(err);
      resolve(this.changes);
    });
  });
}

export function getAllStudents() {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT id, name FROM user WHERE role = "student"';
    db.all(sql, [], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}


// Checks if there are conflicting pairs of students in the same assignment
export function hasConflictingPairs(teacherId, studentIds) {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT g1.student_id AS s1, g2.student_id AS s2, COUNT(*) AS count
      FROM assignments a
      JOIN groups g1 ON a.id = g1.assignment_id
      JOIN groups g2 ON a.id = g2.assignment_id
      WHERE a.teacher_id = ?
        AND g1.student_id < g2.student_id
        AND g1.student_id IN (${studentIds.map(() => '?').join(',')})
        AND g2.student_id IN (${studentIds.map(() => '?').join(',')})
      GROUP BY g1.student_id, g2.student_id
      HAVING count >= 2
    `;
    const params = [teacherId, ...studentIds, ...studentIds];
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows.length > 0);
    });
  });
}



// Retrieves all answers for a given assignment
export function getAnswersForAssignment(assignmentId) {
  return new Promise((resolve, reject) => {
    const sql = `SELECT * FROM answers WHERE assignment_id = ?`;
    db.all(sql, [assignmentId], (err, rows) => {
      if (err) return reject(err);
      const result = rows.map(a => new Answer(a.id, a.assignment_id, a.student_id, a.text, a.submission_date));
      resolve(result);
    });
  });
}

// Checks if the user exists in the database and verifies the provided password.
export const getUser = (email, password) => {
  return new Promise((resolve, reject) => { //verify the password
    const sql = 'SELECT * FROM user WHERE email = ?';
    db.get(sql, [email], (err, row) => { // Query the database for the user
      if (err) {
        reject(err);
      }
      else if (row === undefined) {  // If no user is found, no existing email
        resolve(false); // Handle in the passport.use in index.mjs
      }
      else {
        const user = { id: row.id, username: row.email, name: row.name, role: row.role };
        const salt = row.salt.trim();
        const hashedPasswordFromDb = Buffer.from(row.password.trim(), 'hex');

        crypto.scrypt(password, salt, 32, function (err, hashedPassword) {
          if (err) reject(err);
          if (!crypto.timingSafeEqual(hashedPasswordFromDb, hashedPassword)) // Compare password
            resolve(false);
          else
            resolve(user);
        });
      }
    });
  });
};

// Retrieves summary of the class for a given teacher
export function getClassSummary(teacherId) {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT u.id, u.name,
        SUM(CASE WHEN a.isOpen = 1 THEN 1 ELSE 0 END) AS openCount,
        SUM(CASE WHEN a.isOpen = 0 THEN 1 ELSE 0 END) AS closedCount,
        ROUND(SUM(CASE WHEN a.evaluation IS NOT NULL THEN a.evaluation * (1.0 / gc.cnt) ELSE 0 END), 2)
        / NULLIF(SUM(CASE WHEN a.evaluation IS NOT NULL THEN (1.0 / gc.cnt) ELSE 0 END), 0) AS weightedAvg
      FROM user u
      LEFT JOIN groups g ON u.id = g.student_id
      LEFT JOIN assignments a ON a.id = g.assignment_id AND a.teacher_id = ?
      LEFT JOIN (
        SELECT assignment_id, COUNT(student_id) AS cnt
        FROM groups
        GROUP BY assignment_id
      ) AS gc ON gc.assignment_id = a.id
      WHERE u.role = 'student'
      GROUP BY u.id, u.name
    `;
    db.all(sql, [teacherId], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

export function getAllTeachers() {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT id, name FROM user WHERE role = "teacher"';
    db.all(sql, [], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}


