// import
import express from 'express';
import morgan from 'morgan';
import { check, validationResult } from 'express-validator';
import cors from 'cors';

import passport from 'passport';
import LocalStrategy from 'passport-local';
import session from 'express-session';

import * as dao from './dao.mjs';

// init
const app = express();
const port = 3001;

// middleware
app.use(express.json());
app.use(morgan('dev'));

// Allow requests only from this specific origin, frontend running on localhost:5173
const corsOptions = {
  origin: 'http://localhost:5173',
  optionsSuccessState: 200,
  credentials: true
};
app.use(cors(corsOptions));

passport.use(new LocalStrategy(async function verify(username, password, cb) {
  const user = await dao.getUser(username, password);
  if (!user)
    return cb(null, false, { message: 'Incorrect credentials' });
  return cb(null, user);
}));

passport.serializeUser(function (user, cb) {
  cb(null, user);
});

passport.deserializeUser(function (user, cb) {
  return cb(null, user);
});

const isLoggedIn = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  return res.status(401).json({ error: 'Not authorized' });
};

app.use(session({
  secret: "it's a secret!",
  resave: false,
  saveUninitialized: false,
}));
app.use(passport.authenticate('session'));

/* ROUTES */
// SESSION ************************************************************************

app.post('/api/sessions', function (req, res, next) {
  console.log('Login request body:', req.body);  // Debug: controlla se email e password arrivano

  passport.authenticate('local', (err, user, info) => {
    if (err) return next(err);

    if (!user) {
      return res.status(401).json({ error: info?.message || 'Incorrect credentials' });
    }

    req.login(user, (err) => {
      if (err) return next(err);
      return res.status(201).json(user);
    });
  })(req, res, next);
});


app.get('/api/sessions/current', (req, res) => {
  console.log('BODY IN LOGIN:', req.body);  // <––– aggiungi questo

  if (req.isAuthenticated()) {
    res.json(req.user);
  } else {
    res.status(401).json({ error: 'Not authenticated' });
  }
});

app.delete('/api/sessions/current', (req, res, next) => {
  req.logout(function (err) {
    if (err) return next(err);
    res.end();
  });
});




// TEACHER ***********************************************************************
app.get('/api/teacher/assignments', isLoggedIn, async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Forbidden' });

  try {
    console.log('Try GET /api/teacher/assignments from user', req.user.id);
    const list = await dao.getTeacherAssignments(req.user.id);
    res.json(list);
  } catch (err) {
    console.error('Error getTeacherAssignments:', err);
    res.status(500).json({ error: 'Error teachers assignments data recovery' });
  }
});

app.post('/api/teacher/assignments', isLoggedIn, [
  check('question').notEmpty(),
  check('studentIds').isArray({ min: 2, max: 6 })
], async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Forbidden' });

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

  try {
    const conflict = await dao.hasConflictingPairs(req.user.id, req.body.studentIds);
    if (conflict) {
      return res.status(409).json({ error: 'Students already collaborated at least twice.' });
    }

    const assignmentId = await dao.createAssignment(req.body.question, req.user.id, req.body.studentIds);
    res.status(201).json({ assignmentId });
  } catch (err) {
    res.status(503).json({ error: err.message });
  }
});


app.get('/api/teacher/class', isLoggedIn, async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Forbidden' });

  try {
    const classSummary = await dao.getClassSummary(req.user.id);
    res.json(classSummary);
  } catch (err) {
    console.error('Error backend:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/teacher/assignments/details', isLoggedIn, async (req, res) => {
  try {
    const rawAssignments = await dao.getTeacherAssignments(req.user.id);
    const assignmentsWithStudents = await Promise.all(rawAssignments.map(async (a) => {
      const group = await dao.getAssignmentGroup(a.id);
      const answers = await dao.getAnswersForAssignment(a.id);
      const text = answers.length > 0 ? answers[0].text : null;
      return { ...a, students: group.map(s => s.name), answer: text };
    }));
    res.json(assignmentsWithStudents);
  } catch (err) {
    res.status(500).json({ error: 'Error retrieving assignment' });
  }
});

app.get('/api/assignments/:id/group', isLoggedIn, async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Forbidden' });

  try {
    const group = await dao.getAssignmentGroup(req.params.id);
    res.json(group);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/assignments/:id/evaluate', isLoggedIn, [
  check('evaluation').isInt({ min: 0, max: 30 })
], async (req, res) => {
  if (req.user.role !== 'teacher') return res.status(403).json({ error: 'Forbidden' });

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

  try {
    await dao.evaluateAssignment(req.params.id, req.body.evaluation);
    res.status(204).end();
  } catch (err) {
    res.status(503).json({ error: err.message });
  }
});

// TEACHER LIST
app.get('/api/teachers', isLoggedIn, async (req, res) => {
  try {
    const teachers = await dao.getAllTeachers();
    res.json(teachers);
  } catch (err) {
    res.status(500).json({ error: 'Error retrieving teachers' });
  }
});

// SHARED ************************************************************************
app.get('/api/assignments/:id/answers', isLoggedIn, async (req, res) => {
  try {
    const answers = await dao.getAnswersForAssignment(req.params.id);
    res.json(answers);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// STUDENTS LIST *******************************************************************
app.get('/api/students', isLoggedIn, async (req, res) => {
  try {
    const students = await dao.getAllStudents();
    res.json(students);
  } catch (err) {
    res.status(500).json({ error: 'Error retrieving students' });
  }
});

// STUDENT ************************************************************************
app.get('/api/student/assignments', isLoggedIn, async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Forbidden' });

  try {
    const list = await dao.getStudentAssignments(req.user.id);
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/student/assignments/details', isLoggedIn, async (req, res) => {
  try {
    const assignments = await dao.getStudentAssignmentsWithDetails(req.user.id);
    res.json(assignments);
  } catch (err) {
    res.status(500).json({ error: 'Error retrieving assignment details' });
  }
});

app.post('/api/assignments/:id/answer', isLoggedIn, [check('text').notEmpty()], async (req, res) => {
  if (req.user.role !== 'student') return res.status(403).json({ error: 'Forbidden' });

  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

  try {
    await dao.addOrUpdateAnswer({
      assignmentId: req.params.id,
      text: req.body.text
    });

    res.status(204).end();
  } catch (err) {
    res.status(503).json({ error: err.message });
  }
});


// server
app.listen(port, () => {
  console.log(`API server started at http://localhost:${port}`);
});
