import dayjs from 'dayjs';

function Answer(id, assignmentId, studentId, text, submissionDate, evaluation) {
  this.id = id;
  this.assignmentId = assignmentId;
  this.studentId = studentId;
  this.text = text;
  this.submissionDate = dayjs(submissionDate);
  this.evaluation = evaluation; // Can be null at the start
}

function User(id, name, email, role) {
  this.id = id;
  this.name = name;
  this.email = email;
  this.role = role; // 'student' or 'teacher'
}

function Assignment(id, question, isOpen, evaluation, teacherId, createdAt) {
  this.id = id;
  this.question = question;
  this.isOpen = Boolean(isOpen); //  0/1 -> true/false
  this.evaluation = evaluation; // Can be null at the start
  this.teacherId = teacherId;
  this.createdAt = dayjs(createdAt);
}


export { Answer, Assignment, User };