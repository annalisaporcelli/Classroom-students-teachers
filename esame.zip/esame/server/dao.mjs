//Data Access Object (DAO) module for accessing 

import sqlite from 'sqlite3';
import { Assignment, User, Answer } from './QAModels.mjs';
import crypto from 'crypto';
import dayjs from 'dayjs';

// open the database
const db = new sqlite.Database('db.sqlite', (err) => {
  if (err) throw err;
});


export function getStudentAssignmentsWithDetails(studentId) { // Retrieves all assignments for a student with their details
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT a.*, ans.text AS answerText, t.name AS teacherName 
      FROM assignments a 
      JOIN groups g ON g.assignment_id = a.id
      LEFT JOIN answers ans ON ans.assignment_id = a.id
      LEFT JOIN user t ON a.teacher_id = t.id
      WHERE g.student_id = ?
    `;

    db.all(sql, [studentId], async (err, rows) => {
      if (err) return reject(err);

      try {
        const result = await Promise.all(rows.map(async a => { // For each assignment, get the group of students
          const group = await getAssignmentGroup(a.id); // Get the group of students for the assignment
          return { ...a, group }; // Return the assignment with its group
        }));
        resolve(result); // Resolve the promise with the result
      } catch (err2) {
        reject(err2);
      }
    });
  });
}


//Teacher
export function getTeacherAssignments(teacherId) { // Retrieves all assignments for a teacher with their latest answer
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT a.*,
        (SELECT text FROM answers ans WHERE ans.assignment_id = a.id ORDER BY submission_date DESC LIMIT 1) AS answer
      FROM assignments a
      WHERE a.teacher_id = ?
    `;

    db.all(sql, [teacherId], async (err, rows) => {
      if (err) return reject(err);

      try {
        const result = await Promise.all(rows.map(async (a) => {
          try {
            const group = await getAssignmentGroup(a.id);
            return { ...a, group };
          } catch (innerErr) {
            console.error(`Errore getAssignmentGroup per assignment ${a.id}:`, innerErr);
            return { ...a, group: [] };
          }
        }));
        resolve(result);
      } catch (outerErr) {
        console.error('Errore in Promise.all di getTeacherAssignments:', outerErr);
        reject(outerErr);
      }
    });
  });
}

// Retrieves the group of students for a given assignment
// This function returns a promise that resolves to an array of User objects representing the students in the
// group for the specified assignment ID.
// It uses the SQLite database to query the groups table and join it with the user table to
// retrieve the student details such as ID, name, email, and role.
// The function returns a promise that resolves to an array of User objects or rejects with an error
// if the database query fails.

export function getAssignmentGroup(assignmentId) { // Retrieves the group of students for a given assignment
  return new Promise((resolve, reject) => {
    const sql = `SELECT user.id, user.name, user.email, user.role
                 FROM groups JOIN user ON user.id = groups.student_id
                 WHERE groups.assignment_id = ?`;
    db.all(sql, [assignmentId], (err, rows) => {
      if (err) {
        reject(err);
      } else {
        const group = rows.map(a => new User(a.id, a.name, a.email, a.role));
        resolve(group);
      }
    });
  });
}

// Creates a new assignment with the given question, teacher ID, and student IDs
// This function returns a promise that resolves to the ID of the newly created assignment
// It uses the SQLite database to insert a new record into the assignments table with the provided question
// and teacher ID, and sets the isOpen status to true.
// After inserting the assignment, it prepares a statement to insert the student IDs into the groups table
// for the newly created assignment.
// The function returns a promise that resolves to the ID of the created assignment or rejects with an
// error if the database operation fails.
export function createAssignment(question, teacherId, studentIds) { // Creates a new assignment with the given question, teacher ID, and student IDs
  return new Promise((resolve, reject) => {
    const sql = `INSERT INTO assignments(question, isOpen, teacher_id) VALUES (?, 1, ?)`;
    db.run(sql, [question, teacherId], function (err) {
      if (err) return reject(err);
      const assignmentId = this.lastID;
      const groupSql = `INSERT INTO groups(assignment_id, student_id) VALUES (?, ?)`;

      const stmt = db.prepare(groupSql);
      for (const studentId of studentIds) {
        stmt.run(assignmentId, studentId);
      }
      stmt.finalize((e) => {
        if (e) return reject(e);
        resolve(assignmentId);
      });
    });
  });
}

// Retrieves all assignments for a student
// This function returns a promise that resolves to an array of Assignment objects
// It uses the SQLite database to query the assignments table and join it with the groups table to
// filter assignments based on the student ID provided.
// Each Assignment object is created using the Assignment class constructor, which takes the assignment's
// ID, question, isOpen status, evaluation, teacher ID, and creation date as parameters
// The function returns a promise that resolves to an array of Assignment objects or rejects with an error
// if the database query fails.
export function getStudentAssignments(studentId) {
  return new Promise((resolve, reject) => {
    const sql = `SELECT a.*
                 FROM assignments AS a
                 JOIN groups AS g ON a.id = g.assignment_id
                 WHERE g.student_id = ?`;
    db.all(sql, [studentId], (err, rows) => {
      if (err) return reject(err);
      const result = rows.map(a => new Assignment(a.id, a.question, a.isOpen, a.evaluation, a.teacher_id, a.created_at));
      resolve(result);
    });
  });
}


// Adds or updates an answer for a given assignment
// This function checks if an answer already exists for the assignment ID.
// If it exists, it updates the answer text and submission date.
// If it does not exist, it inserts a new answer with the assignment ID, text,
// The function returns a promise that resolves to the ID of the answer (either updated or newly created).
export function addOrUpdateAnswer({ assignmentId, text }) {
  return new Promise((resolve, reject) => { // 
    const sqlCheck = `SELECT id FROM answers WHERE assignment_id = ?`;
    db.get(sqlCheck, [assignmentId], (err, row) => {
      if (err) return reject(err);
      const now = dayjs().format("YYYY-MM-DD");

      if (row) {
        const sql = `UPDATE answers SET text = ?, submission_date = ? WHERE id = ?`;
        db.run(sql, [text, now, row.id], function (e) {
          if (e) return reject(e);
          resolve(row.id);
        });
      } else {
        const sql = `INSERT INTO answers(assignment_id, text, submission_date)
                     VALUES (?, ?, ?)`;
        db.run(sql, [assignmentId, text, now], function (e) {
          if (e) return reject(e);
          resolve(this.lastID);
        });
      }
    });
  });
}

// // update an existing answer
// export const updateAnswer = (answer) => {
//   return new Promise((resolve, reject) => {
//     let sql = "UPDATE answer SET text = ?, authorId = ?, date = ?, score = ? WHERE id = ?"
//     db.run(sql, [answer.text, answer.userId, answer.date, answer.score, answer.id], function (err) {
//       if (err)
//         reject(err);
//       else
//         resolve(this.lastID);
//     });
//   });
// }


// Retrieves all assignments for a teacher with their answers
// This function returns a promise that resolves to an array of assignments with their answers.
// It uses the SQLite database to query the assignments table and left join it with the answers table
// to get the answers for each assignment.
// const sql = `
//   SELECT a.*, ans.text AS answer
//   FROM assignments a
//   LEFT JOIN answers ans ON ans.assignment_id = a.id
//   WHERE a.teacher_id = ?
// `;
// The function returns a promise that resolves to an array of Assignment objects or rejects with an error
// if the database query fails.
export function evaluateAssignment(assignmentId, evaluation) {
  return new Promise((resolve, reject) => {
    const sql = `UPDATE assignments SET evaluation = ?, isOpen = 0 WHERE id = ?`;
    db.run(sql, [evaluation, assignmentId], function (err) {
      if (err) return reject(err);
      resolve(this.changes);
    });
  });
}

export function getAllStudents() {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT id, name FROM user WHERE role = "student"';
    db.all(sql, [], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}


// Checks if there are conflicting pairs of students in the same assignment
// This function takes a teacher ID and an array of student IDs as parameters.
// It queries the database to find pairs of students who have submitted answers for the same assignment
// and have at least two submissions each.
// If such pairs exist, it resolves the promise with true; otherwise, it resolves with false
// The SQL query uses a self-join on the groups table to find pairs of students in the same assignment
// and counts the number of submissions for each pair.
// The function returns a promise that resolves to true if conflicting pairs exist, or false otherwise.
// The function uses parameterized queries to prevent SQL injection attacks.
// The studentIds array is used to filter the pairs based on the provided student IDs.
export function hasConflictingPairs(teacherId, studentIds) {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT g1.student_id AS s1, g2.student_id AS s2, COUNT(*) AS count
      FROM assignments a
      JOIN groups g1 ON a.id = g1.assignment_id
      JOIN groups g2 ON a.id = g2.assignment_id
      WHERE a.teacher_id = ?
        AND g1.student_id < g2.student_id
        AND g1.student_id IN (${studentIds.map(() => '?').join(',')})
        AND g2.student_id IN (${studentIds.map(() => '?').join(',')})
      GROUP BY g1.student_id, g2.student_id
      HAVING count >= 2
    `;
    const params = [teacherId, ...studentIds, ...studentIds];
    db.all(sql, params, (err, rows) => {
      if (err) return reject(err);
      resolve(rows.length > 0);
    });
  });
}

// Retrieves all answers for a given assignment
// This function takes an assignment ID as a parameter and queries the database to get all answers
// associated with that assignment. It returns a promise that resolves to an array of Answer objects.
export function getAnswersForAssignment(assignmentId) {
  return new Promise((resolve, reject) => {
    const sql = `SELECT * FROM answers WHERE assignment_id = ?`;
    db.all(sql, [assignmentId], (err, rows) => {
      if (err) return reject(err);
      const result = rows.map(a => new Answer(a.id, a.assignment_id, a.student_id, a.text, a.submission_date, a.evaluation));
      resolve(result);
    });
  });
}

// Retrieves a user by email and password
// This function checks if the user exists in the database and verifies the provided password.
export const getUser = (email, password) => {
  return new Promise((resolve, reject) => { // Check if the user exists and verify the password
    const sql = 'SELECT * FROM user WHERE email = ?'; //
    db.get(sql, [email], (err, row) => { // Query the database for the user
      if (err) {
        reject(err);
      }
      else if (row === undefined) {  // If no user is found, resolve with false, no existing email
        resolve(false); // Handle in the passport.use in index.mjs
      }
      else {
        const user = { id: row.id, username: row.email, name: row.name, role: row.role };  // ← aggiunto role

        // Applichiamo trim() per sicurezza su salt e password
        const salt = row.salt.trim();
        const hashedPasswordFromDb = Buffer.from(row.password.trim(), 'hex');

        crypto.scrypt(password, salt, 32, function (err, hashedPassword) {
          if (err) reject(err);
          if (!crypto.timingSafeEqual(hashedPasswordFromDb, hashedPassword)) // Compare the stored password with the provided password
            resolve(false); // If the passwords do not match, resolve with false
          else
            resolve(user); // If the passwords match, resolve with the user object
        });
      }
    });
  });
};

// Retrieves a summary of the class for a given teacher
// This function returns a promise that resolves to an array of objects containing the student ID, name,
// the count of open assignments, the count of closed assignments, and the weighted average evaluation for
// each student in the class taught by the specified teacher.

export function getClassSummary(teacherId) {
  return new Promise((resolve, reject) => {
    const sql = `
      SELECT u.id, u.name,
        SUM(CASE WHEN a.isOpen = 1 THEN 1 ELSE 0 END) AS openCount,
        SUM(CASE WHEN a.isOpen = 0 THEN 1 ELSE 0 END) AS closedCount,
        ROUND(SUM(CASE WHEN a.evaluation IS NOT NULL THEN a.evaluation * (1.0 / gc.cnt) ELSE 0 END), 2)
        / NULLIF(SUM(CASE WHEN a.evaluation IS NOT NULL THEN (1.0 / gc.cnt) ELSE 0 END), 0) AS weightedAvg
      FROM user u
      LEFT JOIN groups g ON u.id = g.student_id
      LEFT JOIN assignments a ON a.id = g.assignment_id AND a.teacher_id = ?
      LEFT JOIN (
        SELECT assignment_id, COUNT(student_id) AS cnt
        FROM groups
        GROUP BY assignment_id
      ) AS gc ON gc.assignment_id = a.id
      WHERE u.role = 'student'
      GROUP BY u.id, u.name
    `;
    db.all(sql, [teacherId], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

export function getAllTeachers() {
  return new Promise((resolve, reject) => {
    const sql = 'SELECT id, name FROM user WHERE role = "teacher"';
    db.all(sql, [], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}


