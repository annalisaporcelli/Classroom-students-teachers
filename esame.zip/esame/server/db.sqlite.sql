BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS answers (
  assignment_id INTEGER PRIMARY KEY,
  text TEXT NOT NULL,
  submission_date TEXT NOT NULL,
  FOREIGN KEY (assignment_id) REFERENCES assignments(id)
);
CREATE TABLE IF NOT EXISTS "assignments" (
	"id"	INTEGER NOT NULL,
	"question"	TEXT NOT NULL,
	"isOpen"	INTEGER NOT NULL DEFAULT 1 CHECK("isOpen" IN (0, 1)),
	"evaluation"	INTEGER CHECK("evaluation" BETWEEN 0 AND 30),
	"teacher_id"	INTEGER NOT NULL,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("teacher_id") REFERENCES "users"("id")
);
CREATE TABLE IF NOT EXISTS groups (
  assignment_id INTEGER NOT NULL,
  student_id INTEGER NOT NULL,
  PRIMARY KEY (assignment_id, student_id),
  FOREIGN KEY (assignment_id) REFERENCES assignments(id),
  FOREIGN KEY (student_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS teacher_assignments (
  teacher_id INTEGER NOT NULL,
  assignment_id INTEGER NOT NULL UNIQUE,
  FOREIGN KEY (teacher_id) REFERENCES users(id),
  FOREIGN KEY (assignment_id) REFERENCES assignments(id)
);
CREATE TABLE IF NOT EXISTS "users" (
	"id"	INTEGER NOT NULL UNIQUE,
	"name"	TEXT NOT NULL,
	"email"	TEXT NOT NULL,
	"password"	TEXT NOT NULL,
	"salt"	TEXT NOT NULL,
	"role"	TEXT NOT NULL CHECK(role IN ('student', 'teacher')),
	PRIMARY KEY("id" AUTOINCREMENT)
);
INSERT INTO "answers" ("assignment_id","text","submission_date") VALUES (1,'React is a JavaScript library for building user interfaces. It uses components and enables fast updates through a virtual DOM.','2025-06-24');
INSERT INTO "assignments" ("id","question","isOpen","evaluation","teacher_id") VALUES (0,'Explain the concept of SPA (Single Page Application)',0,27,21),
 (1,'What are the key features of React?',1,NULL,21);
INSERT INTO "groups" ("assignment_id","student_id") VALUES (1,2),
 (1,4),
 (0,19),
 (0,1),
 (1,0);
INSERT INTO "users" ("id","name","email","password","salt","role") VALUES (0,' Annalisa Porcelli','annalisa@student.it','ae9bc3cbf48c8016e5be847c75bbb9905da54c7568a3466d1ce55b1aae89c17f','47bd736ce1f72b907fecd767349add46 ','student'),
 (1,' Linda Raimondo','linda@student.it','b1e19a93c0b0fab920ef3ea0e0d613fa75282d3bf7e6efdc861d0404f14e1424','9e7ab29c66f1b1566ed555945c037319 ','student'),
 (2,' Andrea Porcelli','andrea@student.it','237830ff99c18e2ee5b06a3c8b23f9a6b1cbc4e384503c7fa8986b5b2d0e175b','dfcf01976a1162cca93f1aa5d35c729d','student'),
 (3,' Silvia La Notte','silvia@student.it','7810839c13ea41f75eac7595b0193581eaf52f4b43696cdcfba5d665357c6215','4fa3815ad15e69bd843a8fb8666a8282','student'),
 (4,' Erica Porcelli','erica@student.it','56f75788fa38c976c146e2296b9e8ee390c1b7220261566fa0cc65d5c1170c7c','731e81ee8a7de9f7808233fbd8685ada','student'),
 (5,' Anna Valente','anna@student.it','07eaee8c2178ce28b9ff425b0a1aafc30d4ff39384a903fe4191d44a9608a622','6b4f822ff6b3b66963b417114888133e','student'),
 (6,' Angelo Porcelli','angelo@student.it','ab3b896aefd7507f768e9422f36732580124f9290be82b89babd72e497331d33','28a733b5214909768fd9421147630b6a','student'),
 (7,' Marco D''amore','marco@student.it','e10f18e81543a7c7b59a570a0d04d499b3584c236f64eb3012a8d99604a95207','3a9428edddcc489d25a6b24c681b7dfb','student'),
 (8,' Carola Cuttone','carola@student.it','a06c99bbd6ef38cf6e8730954da5fcdc70afd7354ce2d92bf6695ce11b941bc4','90c40d2a14b20f48532fdc10bc07bfe0','student'),
 (9,' Sara Vallero','sara@student.it','8369b5b3e788717294c3d2d266fc9c922fc13ff587e2d623ef9da3aafec030d4','2931bb1fee37d8aa163380395653d4da','student'),
 (10,' Serena Spizzico','serena@student.it','f8e0405b9347b00edbd38080db3c0e6720b3fdc746f08fdb6f9258004f80cb43','b8760a8195a0aa96b587e983ae5dec7d','student'),
 (11,' Irene Scaringi','irene@student.it','9c2ec8c41078af4735069b973b0a9b424496cc5eb58ca00a5b0349d9ab377f80','0e92948177e3479160e12c408026748c','student'),
 (12,' Marta Cattaneo','marta@student.it','654fc9fbeb8b04fb11ecda3f36f52bf1435c783fb8c3c7389eb275f61928fe25','42787c9f4429fb82569088d1ebf5908c','student'),
 (13,' Paola Macciotta','paola@student.it','1d4f59130a69d73085499912b3ac79fedae73a8654084e21555b45261dc69f4b','ccb31905fa19f46cc6fc7dcfa1ce6c77','student'),
 (14,' Elisa Uazzaz','elisa@student.it','04ea4587f2c2de8bad13ae152e71f3de4e5a66cacef5fe775c481d3321445ff5','82858c0fdac17176ac8fe646bbdc7aa3','student'),
 (15,' Paolo Gualberto','paolo@student.it','336e13b4a92894ce5dff15a7c9483634b96c2899d443771f518241a958e12d41','65cf8f612e69da1956977296557bf50c','student'),
 (16,' Alice Prunotto','alice@student.it','92e0c112e91d461a65d23b2793fa85713ab8876802b9d26993690bcb498a3655','8c754302474dd7502c92d1d2d1023d69','student'),
 (17,' Rocco Grassia','rocco@student.it','f71d22934350caaaeafc4af86f4bdd67f82e4818ee82ba445276edf7a480f5d4','ff579c503793aa2d1600288856f0f135','student'),
 (18,' Roberto Di Liddo','roberto@student.it','5b312285fc601bdce424b3b3278708a303ce3bda743cc27f43ca5aabc145fe30','d9b85cb2af981a2dc9f233b44a26e00c','student'),
 (19,' Laila Lovino','laila@student.it','1f44e3474f3a5239def064798095f1b331d5239aee747d93ac671fe41e8e7723','f870bd239ecdca327b2e3782c890ff23','student'),
 (20,' Francesca Migliasso','francesca@student.it','08a0afeb5be719e9751a26de95b1b6d1b9656625354051a0f1c8e139beaa97c1','b1ca700d930de31dd9bb840d26891d32','student'),
 (21,' Fulvio Corno','fulviocorno@teacher.it','45e99938fd5347c2b7fe5fe354f76eddac4e7c0f5e17a9e222bfc858bc3993e1','249335f1042221dd3abcff9348df05c3 ','teacher'),
 (22,' Francesca Russo','francescarusso@teacher.it','621bb091df41803b38246ffd47c8760a15c56c37678805eacfd4626ecaddd5d9','487e51c24bef763ed9f67ce066baa61f','teacher');
COMMIT;
