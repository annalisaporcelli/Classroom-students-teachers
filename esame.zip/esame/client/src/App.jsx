import "bootstrap/dist/css/bootstrap.min.css";
import { useEffect, useState } from "react";

import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';


import DefaultLayout from "./components/DefaultLayout";
import { Routes, Route, Navigate } from "react-router";
import { LoginForm } from "./components/AuthComponents";
import NotFound from "./components/NotFound";
import API from "./API/API.mjs";
import TeacherDashboard from './components/TeacherDashboard';
import TeacherHome from "./components/TeacherHome";
import { useNavigate } from "react-router";
import StudentDashboard from './components/StudentDashboard';
import StudentAssignmentsPage from './components/StudentAssignmentsPage';


function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [loadingUser, setLoadingUser] = useState(true); // weiting for user
  const [message, setMessage] = useState(''); // alert message
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const user = await API.getUserInfo();
        setLoggedIn(true);
        setUser(user);
      } catch (err) {
        setLoggedIn(false);
        setUser(null);
      } finally {
        setLoadingUser(false);
      }
    };
    checkAuth();

  }, []);

  useEffect(() => {
    if (loggedIn && user) {
      if (user.role === 'teacher') navigate('/teacher');
      else if (user.role === 'student') navigate('/student');
    }
  }, [loggedIn, user]);


  const handleLogin = async (credentials) => {
    try {
      const user = await API.logIn(credentials);
      setLoggedIn(true);
      setMessage({ msg: `Welcome, ${user.name}!`, type: 'success' });
      setUser(user);

      /* if (user.role === 'teacher')
        navigate('/teacher');
      else if (user.role === 'student') navigate('/student');
      else
        navigate('/');  // o /student */

    } catch (err) {
      setMessage({ msg: err, type: 'danger' });
    }
  };


  const handleLogout = async () => {
    await API.logOut();
    setLoggedIn(false);
    setUser(null);
    setMessage('');
  };

  if (loadingUser) return null; // Block rendering until user info is loaded

  return (
    <Routes>
      <Route
        element={
          <DefaultLayout
            loggedIn={loggedIn}
            handleLogout={handleLogout}
            message={message}
            setMessage={setMessage}
            user={user}
          />
        }
      >
        <Route
          path="/" element={loggedIn && user ? (<Navigate to={user.role === 'teacher' ? "/teacher" : "/student"}
            replace />) : (<h2 className="m-4">Welcome</h2>)}
        />

        <Route
          path="/login" element={loggedIn ? (<Navigate replace to="/" />) : (<LoginForm handleLogin={handleLogin} />)}
        />

        <Route path="/teacher" element={loggedIn && user?.role === 'teacher' ? (<TeacherHome />) : (<Navigate to="/" />)} />
        <Route path="/teacher/class" element={loggedIn && user?.role === 'teacher' ? (<TeacherDashboard />) : (<Navigate to="/" />)} />


        <Route path="/student" element={loggedIn && user?.role === 'student' ? (<StudentDashboard user={user} />) : (<Navigate to="/" />)} />
        <Route path="/student/assignments" element={loggedIn && user?.role === 'student' ? (<StudentAssignmentsPage />) : (<Navigate to="/" />)} />



        <Route
          path="*" element={<NotFound />} />
      </Route>

    </Routes>
  );
}

export default App;
