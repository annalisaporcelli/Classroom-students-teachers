
// This component serves as a default layout for the application, providing a consistent header and message display area.ù

import { Alert, Container, Row } from "react-bootstrap";
import { Outlet } from "react-router";
import NavHeader from "./NavHeader";

// Layout principale dell'applicazione
function DefaultLayout({ loggedIn, handleLogout, message, setMessage, user }) {

  return (
    <>
      <NavHeader loggedIn={loggedIn} handleLogout={handleLogout} user={user} />
      <Container fluid className="mt-3">
        {message && <Row>
          <Alert variant={message.type} onClose={() => setMessage('')} dismissible>{message.msg}</Alert>
        </Row>}
        <Outlet />
      </Container>
    </>
  );
}

export default DefaultLayout;
