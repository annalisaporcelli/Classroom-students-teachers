import { useEffect, useState } from 'react';
import { Table, Spinner, Alert } from 'react-bootstrap';
import API from '../API/API.mjs';
import { CaretDownFill, CaretUpFill } from 'react-bootstrap-icons';

export default function ClassOverview() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [sortKey, setSortKey] = useState('name');
    const [ascending, setAscending] = useState(true);

    useEffect(() => {
        API.getClassSummary()
            .then(rows => setData(rows))
            .catch(err => setError(err.message))
            .finally(() => setLoading(false));
    }, []);

    const toggleSort = (key) => {
        if (sortKey === key) {
            setAscending(!ascending);
        } else {
            setSortKey(key);
            setAscending(true);
        }
    };

    const getSortIcon = (key) => {
        if (sortKey !== key) return null;
        return ascending ? <CaretUpFill /> : <CaretDownFill />;
    };

    const sortedData = [...data].sort((a, b) => {
        let result = 0;
        if (sortKey === 'name') result = a.name.localeCompare(b.name);
        if (sortKey === 'total') result = (a.openCount + a.closedCount) - (b.openCount + b.closedCount);
        if (sortKey === 'avg') result = (a.weightedAvg ?? 0) - (b.weightedAvg ?? 0);
        return ascending ? result : -result;
    });

    if (loading) return <Spinner animation="border" />;
    if (error) return <Alert variant="danger">{error}</Alert>;

    return (
        <Table striped bordered hover>
            <thead>
                <tr>
                    <th onClick={() => toggleSort('name')} style={{ cursor: 'pointer' }}>
                        Student {getSortIcon('name')}
                    </th>
                    <th>Open</th>
                    <th>Closed</th>
                    <th onClick={() => toggleSort('avg')} style={{ cursor: 'pointer' }}>
                        Weighted Avg {getSortIcon('avg')}
                    </th>
                    <th onClick={() => toggleSort('total')} style={{ cursor: 'pointer' }}>
                        # Assignments {getSortIcon('total')}
                    </th>
                </tr>
            </thead>
            <tbody>
                {sortedData.map(s => (
                    <tr key={s.id}>
                        <td>{s.name}</td>
                        <td>{s.openCount}</td>
                        <td>{s.closedCount}</td>
                        <td>{s.weightedAvg?.toFixed(2) || '-'}</td>
                        <td>{s.openCount + s.closedCount}</td>
                    </tr>
                ))}
            </tbody>
        </Table>
    );
}
