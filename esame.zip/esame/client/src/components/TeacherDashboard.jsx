import { useEffect, useState } from 'react';
import { Container, Tabs, Tab, Spinner } from 'react-bootstrap';

import AssignmentList from './AssignmentList';
import CreateAssignment from './CreateAssignment';
import ClassOverview from './ClassOverview';

import API from "../API/API.mjs";

function TeacherDashboard() {
    const [assignments, setAssignments] = useState([]);
    const [students, setStudents] = useState([]);
    const [loading, setLoading] = useState(true);

    const loadData = async () => {
        try {
            const [a, s] = await Promise.all([
                API.getTeacherAssignmentsWithDetails(),
                API.getAllStudents()
            ]);
            setAssignments(a);
            setStudents(s);
        } catch (err) {
            console.error('Error loading data:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    if (loading) return <Spinner animation="border" className="m-5" />;

    return (
        <Container className="mt-4">
            <Tabs defaultActiveKey="assignments" id="teacher-tabs" className="mb-3" unmountOnExit>
                <Tab eventKey="assignments" title="Assignments">
                    <AssignmentList
                        assignments={assignments}
                        reloadAssignments={loadData}
                    />
                </Tab>
                <Tab eventKey="create" title="New Assignment" key={students.length}>
                    <CreateAssignment students={students} onCreate={setAssignments} />
                </Tab>
                <Tab eventKey="overview" title="Class">
                    <ClassOverview students={students} />
                </Tab>
            </Tabs>
        </Container>
    );
}

export default TeacherDashboard;
