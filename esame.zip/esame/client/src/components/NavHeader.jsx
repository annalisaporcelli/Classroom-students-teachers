import { useEffect, useState } from 'react';
import { Button, Container, Navbar } from 'react-bootstrap';
import { Link } from "react-router";
import { LogoutButton } from './AuthComponents';

function NavHeader(props) {
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (darkMode)
      document.documentElement.setAttribute("data-bs-theme", "dark");
    else
      document.documentElement.removeAttribute("data-bs-theme");
  }, [darkMode]);

  return (
    <Navbar bg='primary' data-bs-theme='dark'>
      <Container fluid>
        <Link to="/" className="navbar-brand">Home</Link>

        <Button onClick={() => setDarkMode(oldMode => !oldMode)}>
          {darkMode ? <i className="bi bi-sun-fill" /> : <i className="bi bi-moon-fill" />}
        </Button>

        {props.loggedIn ? (
          <>
            {/*{/*  Link per teacher }
            {props.user?.role === 'teacher' && (
              <Link to="/teacher" className="btn btn-light me-2">
                Dashboard Docente
              </Link>
            )}

            {/*  Link per student }
            {props.user?.role === 'student' && (
              <Link to="/student" className="btn btn-light me-2">
                Area Studente
              </Link>
            )}*/}

            {/* Logout */}
            <LogoutButton logout={props.handleLogout} />
          </>
        ) : (
          <Link to='/login' className='btn btn-outline-light'>Login</Link>
        )}
      </Container>
    </Navbar>
  );
}

export default NavHeader;