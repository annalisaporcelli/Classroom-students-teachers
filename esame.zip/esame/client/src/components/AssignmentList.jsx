import React, { useState, useRef } from 'react';
import { Table, Form, Collapse, Button } from 'react-bootstrap';
import { Toast } from 'primereact/toast';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import API from "../API/API.mjs";

function AssignmentList({ assignments, reloadAssignments }) {
    const [evaluations, setEvaluation] = useState({});
    const [expanded, setExpanded] = useState(null);
    const [expandedQuestions, setExpandedQuestions] = useState({});
    const toast = useRef(null);

    const handleChange = (id, value) => {
        setEvaluation(prev => ({ ...prev, [id]: value }));
    };

    const handleSubmit = async (id) => {
        const evaluation = parseInt(evaluations[id]);
        if (isNaN(evaluation) || evaluation < 0 || evaluation > 30) {
            return alert('Invalid mark. Must be between 0 and 30.');
        }

        try {
            await API.evaluateAssignment(id, evaluation);
            await reloadAssignments();
        } catch (err) {
            console.error('Error during evaluation:', err);
        }
    };

    const confirmAddMark = (assignmentId, evaluation) => {
        confirmDialog({
            message: `Confirm score submission ${evaluation}?`,
            header: 'Confirm score',
            icon: 'pi pi-question-circle',
            accept: async () => {
                await handleSubmit(assignmentId);
                toast.current.show({
                    severity: 'success',
                    summary: 'Score submitted',
                    detail: `Score: ${evaluation}`
                });
            }
        });
    };

    const getStatus = (a) => {
        if (!a.isOpen) return 'Closed';
        if (a.answer) return 'Pending';
        return 'Open';
    };

    const getRowClass = (status) => {
        switch (status) {
            case 'Closed': return '';
            case 'Pending': return '';
            case 'Open': return '';
            default: return '';
        }
    };

    return (
        <>
            <Toast ref={toast} />
            <ConfirmDialog />

            <Table bordered>
                <thead className="table-primary text-center">
                    <tr>
                        <th>TITLE</th>
                        <th># STUDENTS</th>
                        <th>STATUS</th>
                        <th>SCORE</th>
                        <th>DETAILS</th>
                    </tr>
                </thead>
                <tbody>
                    {assignments.map(a => {
                        const status = getStatus(a);
                        const isPending = status === 'Pending';
                        const isExpanded = expanded === a.id;
                        const isQuestionExpanded = expandedQuestions[a.id];

                        return (
                            <React.Fragment key={a.id}>
                                <tr className={getRowClass(status)}>
                                    <td>
                                        <div
                                            style={{
                                                maxHeight: '80px',
                                                overflowY: 'auto',
                                                backgroundColor: '#f8f9fa',
                                                padding: '5px',
                                                borderRadius: '4px',
                                                border: '1px solid #dee2e6'
                                            }}
                                        >
                                            <strong>Question: </strong>{a.question}
                                        </div>
                                    </td>
                                    <td>{a.group.length}</td>
                                    <td>{status}</td>
                                    <td>
                                        {isPending ? (
                                            <div className="d-flex align-items-center gap-2">
                                                <Form.Control
                                                    type="number"
                                                    placeholder="Score"
                                                    value={evaluations[a.id] ?? ''}
                                                    onChange={e => handleChange(a.id, e.target.value)}
                                                    style={{ width: '80px' }}
                                                />
                                                <Button
                                                    variant="primary"
                                                    size="sm"
                                                    onClick={() => confirmAddMark(a.id, evaluations[a.id])}
                                                >
                                                    Add mark
                                                </Button>
                                            </div>
                                        ) : (
                                            <div className="text-center">{a.evaluation ?? '-'}</div>
                                        )}
                                    </td>
                                    <td>
                                        <Button
                                            variant="outline-primary"
                                            size="sm"
                                            onClick={() => setExpanded(prev => (prev === a.id ? null : a.id))}
                                            disabled={!a.answer}
                                        >
                                            {isExpanded ? 'Hide' : 'Details'}
                                        </Button>
                                    </td>
                                </tr>
                                <tr>
                                    <td colSpan={5} style={{ padding: 0, borderTop: 'none' }}>
                                        <Collapse in={isExpanded}>
                                            <div className="p-3 bg-light border-top">
                                                <p><strong>Answer:</strong> {a.answer}</p>
                                                <p><strong>Group members:</strong> {a.group.map(s => s.name).join(', ')}</p>
                                            </div>
                                        </Collapse>
                                    </td>
                                </tr>
                            </React.Fragment>
                        );
                    })}
                </tbody>
            </Table>
        </>
    );
}

export default AssignmentList;
