// List of Closed assignments
export function ClosedAssignmentsList({ assignments }) {
    return (
        <div>
            <h5>Assignment Evaluated</h5>
            {assignments.length === 0 ? <p> No evalueated assignment.</p> :
                assignments.map(a => (
                    <div key={a.id}>
                        <strong>{a.question}</strong>: Score {a.evaluation}/30
                    </div>
                ))
            }
        </div>
    );
}
