// Lista assignment inviati ma non valutati
export function PendingEvaluationList({ assignments }) {
    return (
        <div>
            <h5>Waiting for evaluation</h5>
            {assignments.length === 0 ? <p>No waiting for evaluation assignments.</p> :
                assignments.map(a => (
                    <div key={a.id}>
                        <strong>{a.question}</strong> (Answer submitted, missing evaluation)
                    </div>
                ))
            }
        </div>
    );
}