import { useEffect, useState } from 'react';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import API from '../API/API.mjs';
import {
    Container, Row, Col, Dropdown, ButtonGroup, Button,
    Collapse, Spinner
} from 'react-bootstrap';

function StudentAssignmentsPage() {
    const [assignments, setAssignments] = useState([]);
    const [teacherFilter, setTeacherFilter] = useState('ALL');
    const [teachers, setTeachers] = useState([]);
    const [statusFilter, setStatusFilter] = useState('OPEN');
    const [loading, setLoading] = useState(true);
    const [selectedAssignment, setSelectedAssignment] = useState(null);
    const [showClosedDetails, setShowClosedDetails] = useState(null);

    useEffect(() => {
        const load = async () => {
            try {
                const [assignments, teacherList] = await Promise.all([
                    API.getStudentAssignmentsWithDetails(),
                    API.getAllTeachers()
                ]);
                setAssignments(assignments);
                setTeachers(teacherList.map(t => t.name));
            } catch (err) {
                console.error('Loading error:', err);
            } finally {
                setLoading(false);
            }
        };
        load();
    }, []);

    const handleEdit = async (assignment) => {
        const answers = await API.getAssignmentAnswers(assignment.id);
        const myAnswer = answers.find(a => a.student_id === assignment.student_id);
        setSelectedAssignment({ ...assignment, answerText: myAnswer?.text ?? "" });
    };

    const handleSave = async () => {
        await API.submitAnswer(selectedAssignment.id, selectedAssignment.answerText);
        setSelectedAssignment(null);
        const refreshed = await API.getStudentAssignmentsWithDetails();
        setAssignments(refreshed);
    };

    const filteredAssignments = assignments
        .filter(a => teacherFilter === 'ALL' || a.teacherName === teacherFilter)
        .filter(a => {
            if (statusFilter === 'OPEN') return a.isOpen && !a.evaluation;
            if (statusFilter === 'PENDING') return a.isOpen && !a.evaluation && a.answerText;
            if (statusFilter === 'CLOSED') return a.evaluation !== null;
            return true;
        });

    return (
        <>
            <ConfirmDialog />

            <Container className="mt-4">
                <h4 className="mb-3">Filter Assignment</h4>

                <Row className="mb-3 align-items-center">
                    <Col xs="auto">
                        <Dropdown onSelect={setTeacherFilter}>
                            <Dropdown.Toggle variant="secondary">
                                {teacherFilter === 'ALL' ? 'ALL CLASSES' : teacherFilter}
                            </Dropdown.Toggle>
                            <Dropdown.Menu>
                                <Dropdown.Item eventKey="ALL">ALL CLASSES</Dropdown.Item>
                                {teachers.map(t => (
                                    <Dropdown.Item key={t} eventKey={t}>{t}</Dropdown.Item>
                                ))}
                            </Dropdown.Menu>
                        </Dropdown>
                    </Col>
                    <Col xs="auto">
                        <ButtonGroup>
                            <Button
                                variant={statusFilter === 'OPEN' ? 'primary' : 'outline-primary'}
                                onClick={() => setStatusFilter('OPEN')}
                            >
                                Open
                            </Button>
                            <Button
                                variant={statusFilter === 'PENDING' ? 'warning' : 'outline-warning'}
                                onClick={() => setStatusFilter('PENDING')}
                            >
                                Pending
                            </Button>
                            <Button
                                variant={statusFilter === 'CLOSED' ? 'success' : 'outline-success'}
                                onClick={() => setStatusFilter('CLOSED')}
                            >
                                Closed
                            </Button>
                        </ButtonGroup>
                    </Col>
                </Row>

                {loading ? <Spinner animation="border" /> : (
                    <>
                        {filteredAssignments.length === 0 && (
                            <p className="text-muted">No assignment found.</p>
                        )}

                        {filteredAssignments.map(a => (
                            <div key={a.id} className="mb-3 p-3 border rounded">
                                <div className="d-flex justify-content-between align-items-center">
                                    <div>
                                        <strong>{a.question}</strong>{' '}
                                        <span className="text-muted">({a.teacherName})</span>
                                    </div>
                                    {statusFilter === 'OPEN' && (
                                        <Button variant="primary" onClick={() => handleEdit(a)}>Modify answer</Button>
                                    )}
                                    {statusFilter === 'CLOSED' && (
                                        <Button
                                            variant="outline-secondary"
                                            onClick={() =>
                                                setShowClosedDetails(showClosedDetails === a.id ? null : a.id)
                                            }
                                        >
                                            {showClosedDetails === a.id ? 'Hide' : 'Details'}
                                        </Button>
                                    )}
                                </div>

                                {selectedAssignment?.id === a.id && (
                                    <div className="mt-3">
                                        <textarea
                                            className="form-control mb-2"
                                            rows={4}
                                            value={selectedAssignment.answerText}
                                            onChange={(e) =>
                                                setSelectedAssignment(prev => ({
                                                    ...prev,
                                                    answerText: e.target.value
                                                }))
                                            }
                                        />
                                        <Button
                                            className="me-2"
                                            variant="Success"
                                            onClick={() => {
                                                confirmDialog({
                                                    message: 'Are you sure you want to submit the answer?',
                                                    header: 'Confirm Submission',
                                                    icon: 'pi pi-exclamation-triangle',
                                                    acceptLabel: 'Yes',
                                                    rejectLabel: 'No',
                                                    accept: () => handleSave(),
                                                    reject: () => { }
                                                });
                                            }}
                                        >
                                            Save
                                        </Button>
                                        <Button variant="secondary" onClick={() => setSelectedAssignment(null)}>
                                            Cancel
                                        </Button>
                                    </div>
                                )}

                                {showClosedDetails === a.id && (
                                    <Collapse in={showClosedDetails === a.id}>
                                        <div className="mt-3">
                                            <p><strong>Answer:</strong> {a.answerText}</p>
                                            <p><strong>Score:</strong> {a.evaluation}</p>
                                            <p><strong>Group:</strong> {a.group?.map(s => s.name).join(', ')}</p>
                                        </div>
                                    </Collapse>
                                )}
                            </div>
                        ))}
                    </>
                )}
            </Container>
        </>
    );
}

export default StudentAssignmentsPage;
